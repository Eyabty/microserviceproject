package exception;public class ResourceNotFoundException {
}
